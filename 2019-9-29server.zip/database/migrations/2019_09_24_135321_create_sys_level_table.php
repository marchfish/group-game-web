<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSysLevelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sys_level', function (Blueprint $table) {
            $table->charset = 'utf8mb4';
            $table->collation = 'utf8mb4_bin';

            $table->increments('id')->comment('主键 id');
            $table->unsignedInteger('level')->default(0)->comment('等级');
            $table->unsignedInteger('exp')->default(0)->comment('所需经验');
            $table->unsignedInteger('max_hp')->default(5)->comment('血量上限');
            $table->unsignedInteger('max_mp')->default(5)->comment('蓝量上限');
            $table->unsignedInteger('attack')->default(0)->comment('攻击力');
            $table->unsignedInteger('magic')->default(0)->comment('魔力');
            $table->unsignedInteger('crit')->default(0)->comment('暴击');
            $table->unsignedInteger('dodge')->default(0)->comment('闪避');
            $table->unsignedInteger('defense')->default(0)->comment('防御力');
            $table->unsignedInteger('fame_id')->default(0)->comment('称号id');
            $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'))->comment('创建时间');
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'))->comment('修改时间');
        });

        DB::statement("ALTER TABLE `sys_level` comment '等级配置表'");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sys_level');
    }
}
