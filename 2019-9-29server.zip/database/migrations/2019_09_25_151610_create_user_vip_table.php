<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserVipTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_vip', function (Blueprint $table) {
            $table->charset = 'utf8mb4';
            $table->collation = 'utf8mb4_bin';

            $table->increments('id')->comment('主键 id');
            $table->unsignedInteger('user_role_id')->comment('角色id');
            $table->unsignedInteger('level')->default(1)->comment('会员等级');
            $table->unsignedInteger('protect_hp')->default(1)->comment('血量保护');
            $table->unsignedInteger('success_rate')->default(1)->comment('成功率');
            $table->unsignedInteger('buy_count')->default(1)->comment('购买次数');
            $table->unsignedInteger('on_hook_type')->default(1)->comment('挂机类型 1：经验，2：金币');
            $table->timestamp('on_hook_at')->default(DB::raw('CURRENT_TIMESTAMP'))->comment('挂机时间');
            $table->timestamp('expired_at')->default(DB::raw('CURRENT_TIMESTAMP'))->comment('到期时间');
            $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'))->comment('创建时间');
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'))->comment('修改时间');
        });

        DB::statement("ALTER TABLE `user_vip` comment '会员表'");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_vip');
    }
}
