<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEquipTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('equip', function (Blueprint $table) {
            $table->charset = 'utf8mb4';
            $table->collation = 'utf8mb4_bin';

            $table->increments('id')->comment('主键 id');
            $table->unsignedInteger('user_role_id')->comment('角色id');
            $table->unsignedInteger('weapon')->default(0)->comment('武器/物品id');
            $table->unsignedInteger('helmet')->default(0)->comment('头盔/物品id');
            $table->unsignedInteger('clothes')->default(0)->comment('衣服/物品id');
            $table->unsignedInteger('earring')->default(0)->comment('耳环/物品id');
            $table->unsignedInteger('necklace')->default(0)->comment('项链/物品id');
            $table->unsignedInteger('bracelet')->default(0)->comment('手镯/物品id');
            $table->unsignedInteger('ring')->default(0)->comment('戒指/物品id');
            $table->unsignedInteger('shoes')->default(0)->comment('鞋子/物品id');
            $table->unsignedInteger('magic_weapon')->default(0)->comment('法宝/物品id');
            $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'))->comment('创建时间');
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'))->comment('修改时间');
        });

        DB::statement("ALTER TABLE `equip` comment '装备表'");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('equip');
    }
}
