404 Not Found
<?php /**PATH /mnt/hgfs/group/server/resources/views/errors/404.blade.php ENDPATH**/ ?>