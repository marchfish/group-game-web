<?php

return [
    'root'       => base_path('public'),
    'upload_dir' => 'upload',
];
