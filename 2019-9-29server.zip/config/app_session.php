<?php

return [
    'prefix'   => 'app_session:',
    'lifetime' => 60 * 60 * 24 * 7,
];
