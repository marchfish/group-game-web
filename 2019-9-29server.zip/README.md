# group-game-web
群文字游戏-网页版
Welcome to QQ Group: 7829338

## 配置及框架
Laravel 5.7

mysql 5.7.27

php 7.2

nginx

包括数据库在内部分东西不方便上传，请联系群主（具体不懂的都找群主，没时间写文档）。
